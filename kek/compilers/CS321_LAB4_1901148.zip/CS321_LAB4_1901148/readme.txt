Priyanka Kumari : wrote functions first and follows and made lex file
Rutuja Patole : wrote function for left recursion , parse table and string validation