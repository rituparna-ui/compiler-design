typedef struct node 
{ 
    struct node *left; 
    char *value; 
    struct node *right; 
} node; 
