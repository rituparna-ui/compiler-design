/*Here is the 3rd one*/ int b;
/* the final one*/ int c; /*is here*/