Priyanka Kumari : wrote functions first, follows and left factoring and made lex file
Rutuja Patole : wrote function for left recursion , parse table and string validation